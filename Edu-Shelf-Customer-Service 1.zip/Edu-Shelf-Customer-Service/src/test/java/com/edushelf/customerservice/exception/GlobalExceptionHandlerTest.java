package com.edushelf.customerservice.exception;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.edushelf.customerservice.exceptions.CustomerDetailsNotFoundException;
import com.edushelf.customerservice.exceptions.EmailAlreadyExistsException;
import com.edushelf.customerservice.exceptions.GlobalExceptionHandler;
import com.edushelf.customerservice.exceptions.InvalidCustomerIdException;
import com.edushelf.customerservice.exceptions.InvalidPasswordException;
import com.edushelf.customerservice.exceptions.InvalidUsernameException;
import com.edushelf.customerservice.exceptions.UsernameAlreadyExistsException;

class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler globalExceptionHandler;

    @BeforeEach
    void setUp() {
        globalExceptionHandler = new GlobalExceptionHandler();
    }

    @Test
    void testHandleUsernameAlreadyExistsException() {
        UsernameAlreadyExistsException ex = new UsernameAlreadyExistsException("Username already exists");
        ResponseEntity<Object> response = globalExceptionHandler.handleUsernameAlreadyExistsException(ex);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(((Map<?, ?>) response.getBody()).containsKey("message"));
    }

    @Test
    void testHandleEmailAlreadyExistsException() {
        EmailAlreadyExistsException ex = new EmailAlreadyExistsException("Email already exists");
        ResponseEntity<Object> response = globalExceptionHandler.handleEmailAlreadyExistsException(ex);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(((Map<?, ?>) response.getBody()).containsKey("message"));
    }

    @Test
    void testHandleInvalidUsernameException() {
        InvalidUsernameException ex = new InvalidUsernameException("Invalid username");
        ResponseEntity<Object> response = globalExceptionHandler.handleInvalidUsernameException(ex);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(((Map<?, ?>) response.getBody()).containsKey("message"));
    }

    @Test
    void testHandleInvalidPasswordException() {
        InvalidPasswordException ex = new InvalidPasswordException("Invalid password");
        ResponseEntity<Object> response = globalExceptionHandler.handleInvalidPasswordException(ex);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(((Map<?, ?>) response.getBody()).containsKey("message"));
    }

    @Test
    void testHandleCustomerDetailsNotFoundException() {
        CustomerDetailsNotFoundException ex = new CustomerDetailsNotFoundException("Customer details not found");
        ResponseEntity<Object> response = globalExceptionHandler.handleCustomerDetailsNotFoundException(ex);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(((Map<?, ?>) response.getBody()).containsKey("message"));
    }

    @Test
    void testHandleInvalidCustomerIdException() {
        InvalidCustomerIdException ex = new InvalidCustomerIdException("Invalid customer ID");
        ResponseEntity<Object> response = globalExceptionHandler.handleInvalidCustomerIdException(ex);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(((Map<?, ?>) response.getBody()).containsKey("message"));
    }

    @Test
    void testHandleValidationExceptions() {
        // Mock the MethodArgumentNotValidException
        BindingResult bindingResult = mock(BindingResult.class);
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);

        // Simulate validation errors
        FieldError fieldError = new FieldError("objectName", "fieldName", "Validation error message");
        when(bindingResult.getFieldErrors()).thenReturn(List.of(fieldError));
        when(ex.getBindingResult()).thenReturn(bindingResult);

        ResponseEntity<Object> response = globalExceptionHandler.handleValidationExceptions(ex);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        Map<?, ?> responseBody = (Map<?, ?>) response.getBody();

        assertTrue(responseBody.containsKey("errors"));
        assertEquals("Validation error message", ((Map<?, ?>) responseBody.get("errors")).get("fieldName"));
    }
}
