package com.edushelf.customerservice.contoller;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.edushelf.customerservice.controllers.CustomerController;
import com.edushelf.customerservice.dto.CustomerDetailsResponse;
import com.edushelf.customerservice.dto.LoginResponse;
import com.edushelf.customerservice.dto.UserLoginRequest;
import com.edushelf.customerservice.dto.UserRegistrationRequest;
import com.edushelf.customerservice.dto.UserResponse;
import com.edushelf.customerservice.service.CustomerService;

class CustomerControllerTest {

    @InjectMocks
    private CustomerController customerController;

    @Mock
    private CustomerService customerService;

    private UserRegistrationRequest registrationRequest;
    private UserLoginRequest loginRequest;
    private UserResponse userResponse;
    private LoginResponse loginResponse;
    private CustomerDetailsResponse customerDetailsResponse;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        registrationRequest = new UserRegistrationRequest();
        registrationRequest.setUserName("johnDoe");
        registrationRequest.setEmail("john.doe@example.com");
        registrationRequest.setPassword("password123");
        registrationRequest.setFirstName("John");
        registrationRequest.setLastName("Doe");
        registrationRequest.setIsManager("false");

        loginRequest = new UserLoginRequest();
        loginRequest.setUsername("johnDoe");
        loginRequest.setPassword("password123");

        userResponse = new UserResponse(1L, "john.doe@example.com", "johnDoe", null);
        loginResponse = new LoginResponse("johnDoe", "john.doe@example.com", "jwt-token", null);
        customerDetailsResponse = new CustomerDetailsResponse("John", "Doe", null, null, "john.doe@example.com", "USA");
    }

    @Test
    void testRegister_Success() {
        when(customerService.userRegistration(registrationRequest)).thenReturn(userResponse);

        ResponseEntity<UserResponse> response = customerController.register(registrationRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(customerService, times(1)).userRegistration(registrationRequest);
    }

    @Test
    void testRegister_Failure_InvalidRequest() {
        // Simulate validation failure with an invalid request
        UserRegistrationRequest invalidRequest = new UserRegistrationRequest();
        invalidRequest.setEmail("invalid-email"); // Missing other required fields

        ResponseEntity<UserResponse> response = customerController.register(invalidRequest);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode()); // Assume BAD_REQUEST for invalid input
        assertNull(response.getBody());
        verify(customerService, times(0)).userRegistration(any());
    }

    @Test
    void testLogin_Success() {
        when(customerService.userLogin(loginRequest)).thenReturn(loginResponse);

        LoginResponse response = customerController.login(loginRequest);

        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
        verify(customerService, times(1)).userLogin(loginRequest);
    }

    @Test
    void testLogin_Failure_InvalidCredentials() {
        when(customerService.userLogin(loginRequest)).thenReturn(null);

        LoginResponse response = customerController.login(loginRequest);

        assertNull(response); // Login failed
        verify(customerService, times(1)).userLogin(loginRequest);
    }

    @Test
    void testGetCustomerDetails_Success() {
        when(customerService.getCustomerDetails(1L)).thenReturn(customerDetailsResponse);

        ResponseEntity<CustomerDetailsResponse> response = customerController.details(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(customerService, times(1)).getCustomerDetails(1L);
    }

    @Test
    void testGetCustomerDetails_NotFound() {
        when(customerService.getCustomerDetails(1L)).thenReturn(null);

        ResponseEntity<CustomerDetailsResponse> response = customerController.details(1L);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
        verify(customerService, times(1)).getCustomerDetails(1L);
    }

    @Test
    void testValidateToken_Success() {
        doNothing().when(customerService).validateToke(anyString());

        ResponseEntity<?> response = customerController.validateToken("valid-token");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Token validated successfully.", response.getBody());
        verify(customerService, times(1)).validateToke(anyString());
    }

    @Test
    void testValidateToken_Failure() {
        doThrow(new RuntimeException("Token validation failed")).when(customerService).validateToke(anyString());

        ResponseEntity<?> response = customerController.validateToken("invalid-token");

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertEquals("Token validation failed: Token validation failed", response.getBody());
        verify(customerService, times(1)).validateToke(anyString());
    }

    @Test
    void testValidateToken_InvalidInput() {
        ResponseEntity<?> response = customerController.validateToken(null);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Token is required.", response.getBody());
        verify(customerService, times(0)).validateToke(anyString());
    }
}
