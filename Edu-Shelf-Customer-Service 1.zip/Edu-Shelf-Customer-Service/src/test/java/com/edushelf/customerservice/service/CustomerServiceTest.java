package com.edushelf.customerservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.edushelf.customerservice.Entity.Address;
import com.edushelf.customerservice.Entity.CustomerDetails;
import com.edushelf.customerservice.Entity.Role;
import com.edushelf.customerservice.Entity.User;
import com.edushelf.customerservice.config.JwtUtil;
import com.edushelf.customerservice.dto.CustomerDetailsResponse;
import com.edushelf.customerservice.dto.LoginResponse;
import com.edushelf.customerservice.dto.UserLoginRequest;
import com.edushelf.customerservice.dto.UserRegistrationRequest;
import com.edushelf.customerservice.dto.UserResponse;
import com.edushelf.customerservice.exceptions.*;
import com.edushelf.customerservice.repositories.CustomerDetailsRepository;
import com.edushelf.customerservice.repositories.UserRepository;

class CustomerServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private CustomerDetailsRepository customerDetailsRepository;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private CustomerService customerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // User Registration Test Cases
    @Test
    void testUserRegistration_Success() {
        UserRegistrationRequest request = new UserRegistrationRequest();
        request.setUserName("testUser");
        request.setEmail("test@example.com");
        request.setPassword("password");
        request.setIsManager("false");
        request.setFirstName("Test");
        request.setLastName("User");
        request.setAddress(new Address());

        when(userRepository.existsByUserName(request.getUserName())).thenReturn(false);
        when(userRepository.existsByEmail(request.getEmail())).thenReturn(false);

        User savedUser = new User();
        savedUser.setId(1L);
        savedUser.setUserName(request.getUserName());
        savedUser.setEmail(request.getEmail());
        savedUser.setRoles(Set.of(Role.ROLE_CUSTOMER));

        when(userRepository.save(any(User.class))).thenReturn(savedUser);
        when(customerDetailsRepository.save(any(CustomerDetails.class))).thenReturn(new CustomerDetails());

        UserResponse response = customerService.userRegistration(request);

        assertNotNull(response);
        assertEquals(savedUser.getId(), response.getId());
        assertEquals(savedUser.getUserName(), response.getUsername());
    }

    @Test
    void testUserRegistration_UsernameExists() {
        UserRegistrationRequest request = new UserRegistrationRequest();
        request.setUserName("testUser");

        when(userRepository.existsByUserName(request.getUserName())).thenReturn(true);

        assertThrows(UsernameAlreadyExistsException.class, () -> customerService.userRegistration(request));
    }

    @Test
    void testUserRegistration_EmailExists() {
        UserRegistrationRequest request = new UserRegistrationRequest();
        request.setUserName("testUser");
        request.setEmail("test@example.com");

        when(userRepository.existsByUserName(request.getUserName())).thenReturn(false);
        when(userRepository.existsByEmail(request.getEmail())).thenReturn(true);

        assertThrows(EmailAlreadyExistsException.class, () -> customerService.userRegistration(request));
    }

    @Test
    void testUserRegistration_InvalidIsManagerValue() {
        UserRegistrationRequest request = new UserRegistrationRequest();
        request.setUserName("testUser");
        request.setIsManager("invalid");

        when(userRepository.existsByUserName(request.getUserName())).thenReturn(false);

        assertThrows(RuntimeException.class, () -> customerService.userRegistration(request));
    }

    // User Login Test Cases
    @Test
    void testUserLogin_Success() {
        UserLoginRequest request = new UserLoginRequest();
        request.setUsername("testUser");
        request.setPassword("password");

        User user = new User();
        user.setUserName("testUser");
        user.setPassword("password");
        user.setRoles(Set.of(Role.ROLE_CUSTOMER));

        when(userRepository.findByUserName(request.getUsername())).thenReturn(Optional.of(user));
        when(jwtUtil.generateToken(user.getUserName(), user.getRoles())).thenReturn("testToken");

        LoginResponse response = customerService.userLogin(request);

        assertNotNull(response);
        assertEquals("testUser", response.getUserName());
        assertEquals("testToken", response.getToken());
    }

    @Test
    void testUserLogin_InvalidUsername() {
        UserLoginRequest request = new UserLoginRequest();
        request.setUsername("invalidUser");

        when(userRepository.findByUserName(request.getUsername())).thenReturn(Optional.empty());

        assertThrows(InvalidUsernameException.class, () -> customerService.userLogin(request));
    }

    @Test
    void testUserLogin_InvalidPassword() {
        UserLoginRequest request = new UserLoginRequest();
        request.setUsername("testUser");
        request.setPassword("wrongPassword");

        User user = new User();
        user.setUserName("testUser");
        user.setPassword("password");

        when(userRepository.findByUserName(request.getUsername())).thenReturn(Optional.of(user));

        assertThrows(InvalidPasswordException.class, () -> customerService.userLogin(request));
    }

    // Validate Token Test Case
    @Test
    void testValidateToken_Success() {
        String token = "testToken";

        doNothing().when(jwtUtil).validateToken(token);

        assertDoesNotThrow(() -> customerService.validateToke(token));
    }

    // Fetch Customer Details Test Cases
    @Test
    void testGetCustomerDetails_Success() {
        Long userId = 1L;

        User user = new User();
        user.setEmail("test@example.com");

        Address address = new Address();
        address.setCountry("India");

        CustomerDetails customerDetails = new CustomerDetails();
        customerDetails.setUser(user);
        customerDetails.setFirstName("Test");
        customerDetails.setLastName("User");
        customerDetails.setAddress(address);

        when(customerDetailsRepository.findByUserId(userId)).thenReturn(Optional.of(customerDetails));

        CustomerDetailsResponse response = customerService.getCustomerDetails(userId);

        assertNotNull(response);
        assertEquals("Test", response.getFirstName());
        assertEquals("India", response.getCountry());
    }

    @Test
    void testGetCustomerDetails_InvalidCustomerId() {
        assertThrows(InvalidCustomerIdException.class, () -> customerService.getCustomerDetails(-1L));
    }

    @Test
    void testGetCustomerDetails_CustomerNotFound() {
        Long userId = 1L;

        when(customerDetailsRepository.findByUserId(userId)).thenReturn(Optional.empty());

        assertThrows(CustomerDetailsNotFoundException.class, () -> customerService.getCustomerDetails(userId));
    }
}
