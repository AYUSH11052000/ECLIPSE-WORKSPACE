package com.edushelf.customerservice;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;

import static org.mockito.Mockito.mockStatic;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@SpringBootTest
class EduShelfCustomerServiceApplicationTests {

    @Test
    void testMainMethod() {
        // Mock the SpringApplication.run() method
        try (MockedStatic<SpringApplication> mockedSpringApplication = mockStatic(SpringApplication.class)) {
            String[] args = {};
            assertDoesNotThrow(() -> EduShelfCustomerServiceApplication.main(args));
            // Verify that SpringApplication.run() was called with the correct class and arguments
            mockedSpringApplication.verify(() -> SpringApplication.run(EduShelfCustomerServiceApplication.class, args));
        }
    }

    @Test
    void contextLoads() {
        // Verifies that the application context loads without exceptions
        assertDoesNotThrow(() -> {
            // No specific logic is required; @SpringBootTest ensures context loading
        });
    }
}
