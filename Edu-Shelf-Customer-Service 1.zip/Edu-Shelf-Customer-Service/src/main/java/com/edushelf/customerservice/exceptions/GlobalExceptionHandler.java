package com.edushelf.customerservice.exceptions;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	// Handle UsernameAlreadyExistsException
	@ExceptionHandler(UsernameAlreadyExistsException.class)
	public ResponseEntity<Object> handleUsernameAlreadyExistsException(UsernameAlreadyExistsException ex) {
		return buildErrorResponse(HttpStatus.CONFLICT, ex.getMessage());
	}

	// Handle EmailAlreadyExistsException
	@ExceptionHandler(EmailAlreadyExistsException.class)
	public ResponseEntity<Object> handleEmailAlreadyExistsException(EmailAlreadyExistsException ex) {
		return buildErrorResponse(HttpStatus.CONFLICT, ex.getMessage());
	}

	// Handle InvalidUsernameException
	@ExceptionHandler(InvalidUsernameException.class)
	public ResponseEntity<Object> handleInvalidUsernameException(InvalidUsernameException ex) {
		return buildErrorResponse(HttpStatus.UNAUTHORIZED, ex.getMessage());
	}

	// Handle InvalidPasswordException
	@ExceptionHandler(InvalidPasswordException.class)
	public ResponseEntity<Object> handleInvalidPasswordException(InvalidPasswordException ex) {
		return buildErrorResponse(HttpStatus.UNAUTHORIZED, ex.getMessage());
	}

	// Handle CustomerDetailsNotFoundException
	@ExceptionHandler(CustomerDetailsNotFoundException.class)
	public ResponseEntity<Object> handleCustomerDetailsNotFoundException(CustomerDetailsNotFoundException ex) {
		return buildErrorResponse(HttpStatus.NOT_FOUND, ex.getMessage());
	}

	// Handle InvalidCustomerIdException
	@ExceptionHandler(InvalidCustomerIdException.class)
	public ResponseEntity<Object> handleInvalidCustomerIdException(InvalidCustomerIdException ex) {
		return buildErrorResponse(HttpStatus.BAD_REQUEST, ex.getMessage());
	}

	// Handle Validation Errors
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();

		for (FieldError error : ex.getBindingResult().getFieldErrors()) {
			errors.put(error.getField(), error.getDefaultMessage());
		}

		Map<String, Object> response = new HashMap<>();
		response.put("timestamp", LocalDateTime.now());
		response.put("status", HttpStatus.BAD_REQUEST.value());
		response.put("error", "Validation Error");
		response.put("message", "Validation failed for one or more fields");
		response.put("errors", errors);

		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}


	// Method to build a standardized error response
	private ResponseEntity<Object> buildErrorResponse(HttpStatus status, String message) {
		Map<String, Object> response = new HashMap<>();
		response.put("timestamp", LocalDateTime.now());
		response.put("status", status.value());
		response.put("error", status.getReasonPhrase());
		response.put("message", message);
		return new ResponseEntity<>(response, status);
	}
}
