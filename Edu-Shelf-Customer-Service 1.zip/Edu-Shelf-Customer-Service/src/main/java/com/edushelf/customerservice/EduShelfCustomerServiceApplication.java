package com.edushelf.customerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class EduShelfCustomerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduShelfCustomerServiceApplication.class, args);
	}

}
