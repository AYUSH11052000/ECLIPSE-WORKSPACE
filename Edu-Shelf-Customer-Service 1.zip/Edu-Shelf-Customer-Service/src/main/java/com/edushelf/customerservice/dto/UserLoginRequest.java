package com.edushelf.customerservice.dto;

import jakarta.validation.constraints.NotBlank;

public class UserLoginRequest {

	@NotBlank(message = "Username is required")
	private String userName;

	@NotBlank(message = "Password is required")
	private String password;

	public String getUsername() {
		return userName;
	}

	public void setUsername(String username) {
		this.userName = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
