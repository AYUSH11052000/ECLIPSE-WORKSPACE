package com.edushelf.customerservice.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edushelf.customerservice.Entity.CustomerDetails;

@Repository
public interface CustomerDetailsRepository extends JpaRepository<CustomerDetails, Long> {

	Optional<CustomerDetails> findByUserId(Long userId);
	
	
}
