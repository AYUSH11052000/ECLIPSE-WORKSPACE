package com.edushelf.customerservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edushelf.customerservice.Entity.User;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import com.edushelf.customerservice.Entity.Role;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByUserName(String userName);

//	These methods are used to validate user inputs during registration
	// Checks if username exists
	boolean existsByUserName(String userName);

//	Checks if email exists
	boolean existsByEmail(String email);

	// fetch users with specific roles
	List<User> findByRolesContaining(Role role);
}
