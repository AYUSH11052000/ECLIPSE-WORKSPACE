package com.edushelf.customerservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class CustomerSecurityConfig {

	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http
	    .authorizeHttpRequests(auth -> auth
	        .requestMatchers("/customers/register", "/customers/login","/customers/{userId}/details", "/customers/validate-token").permitAll()
	    )
	    .csrf(csrf -> csrf.disable())
	    .httpBasic();
		
		return http.build();
    }
}