package com.edushelf.customerservice.exceptions;

//Exception for Invalid Email Format
public class EmailAlreadyExistsException extends RuntimeException {
	public EmailAlreadyExistsException(String message) {
		super(message);
	}
}
