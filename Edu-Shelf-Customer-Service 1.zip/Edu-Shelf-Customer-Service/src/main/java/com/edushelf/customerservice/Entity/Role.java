package com.edushelf.customerservice.Entity;

public enum Role {
    ROLE_CUSTOMER,
    ROLE_MANAGER
}
