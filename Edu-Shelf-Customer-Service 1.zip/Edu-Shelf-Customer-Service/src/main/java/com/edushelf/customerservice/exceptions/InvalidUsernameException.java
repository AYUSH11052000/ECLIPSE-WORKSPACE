package com.edushelf.customerservice.exceptions;

public class InvalidUsernameException extends RuntimeException{
	public InvalidUsernameException(String message) {
		super(message);
	}
	
}
