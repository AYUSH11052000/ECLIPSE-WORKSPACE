package com.edushelf.customerservice.exceptions;

//Exception for Username Already Exists
public class UsernameAlreadyExistsException extends RuntimeException {
	public UsernameAlreadyExistsException(String message) {
		super(message);
	}
}