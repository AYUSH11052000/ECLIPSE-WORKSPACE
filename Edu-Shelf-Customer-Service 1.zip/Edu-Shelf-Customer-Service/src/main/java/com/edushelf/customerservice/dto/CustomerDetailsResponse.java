package com.edushelf.customerservice.dto;

import java.time.LocalDate;

import com.edushelf.customerservice.Entity.Address;

public class CustomerDetailsResponse {

	private String firstName;
	private String lastName;
	private Address address;
	private LocalDate dob;
	private String email;
	private String country;

	// Constructor
	public CustomerDetailsResponse(String firstName, String lastName, Address address, LocalDate dob, String email,
			String country) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.dob = dob;
		this.email = email;
		this.country = country;
	}

	// Getters and Setters
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
}
