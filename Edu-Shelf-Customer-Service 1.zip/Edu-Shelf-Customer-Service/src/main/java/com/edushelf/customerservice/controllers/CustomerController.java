package com.edushelf.customerservice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.edushelf.customerservice.dto.CustomerDetailsResponse;
import com.edushelf.customerservice.dto.LoginResponse;
import com.edushelf.customerservice.dto.UserLoginRequest;
import com.edushelf.customerservice.dto.UserRegistrationRequest;
import com.edushelf.customerservice.dto.UserResponse;
import com.edushelf.customerservice.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/customers")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@PostMapping("/register")
	public ResponseEntity<UserResponse> register(@Valid @RequestBody UserRegistrationRequest request) {
		UserResponse response = customerService.userRegistration(request);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping("/login")
	public LoginResponse login(@Valid @RequestBody UserLoginRequest request) {
		return customerService.userLogin(request);
	}

	
	@GetMapping("/{userId}/details")
	public ResponseEntity<CustomerDetailsResponse> details(@PathVariable Long userId) {
		CustomerDetailsResponse response = customerService.getCustomerDetails(userId);
		if (response != null) {
			return new ResponseEntity<>(response, HttpStatus.OK); // 200 OK
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404
		}
	}

	@GetMapping("/validate-token")
	public ResponseEntity<?> validateToken(@RequestParam String token) {
		System.out.println("Validating the Token");
		try {
			customerService.validateToke(token); // Call the service to validate the token
			return ResponseEntity.ok("Token validated successfully.");
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Token validation failed: " + e.getMessage());
		}
	}
}
