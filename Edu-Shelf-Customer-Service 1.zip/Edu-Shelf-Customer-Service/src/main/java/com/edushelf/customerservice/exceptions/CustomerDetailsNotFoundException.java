package com.edushelf.customerservice.exceptions;

public class CustomerDetailsNotFoundException extends RuntimeException{

	public CustomerDetailsNotFoundException(String message) {
		super(message);
	}

}
