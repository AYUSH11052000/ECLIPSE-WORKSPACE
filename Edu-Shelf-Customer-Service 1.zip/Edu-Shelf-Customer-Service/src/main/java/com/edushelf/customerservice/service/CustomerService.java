package com.edushelf.customerservice.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edushelf.customerservice.Entity.CustomerDetails;
import com.edushelf.customerservice.Entity.Role;
import com.edushelf.customerservice.Entity.User;
import com.edushelf.customerservice.config.JwtUtil;
import com.edushelf.customerservice.dto.CustomerDetailsResponse;
import com.edushelf.customerservice.dto.LoginResponse;
import com.edushelf.customerservice.dto.UserLoginRequest;
import com.edushelf.customerservice.dto.UserRegistrationRequest;
import com.edushelf.customerservice.dto.UserResponse;
import com.edushelf.customerservice.exceptions.CustomerDetailsNotFoundException;
import com.edushelf.customerservice.exceptions.EmailAlreadyExistsException;
import com.edushelf.customerservice.exceptions.InvalidCustomerIdException;
import com.edushelf.customerservice.exceptions.InvalidPasswordException;
import com.edushelf.customerservice.exceptions.InvalidUsernameException;
import com.edushelf.customerservice.exceptions.UsernameAlreadyExistsException;
import com.edushelf.customerservice.repositories.CustomerDetailsRepository;
import com.edushelf.customerservice.repositories.UserRepository;

@Service
public class CustomerService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CustomerDetailsRepository customerDetailsRepository;

	@Autowired
	private JwtUtil jwtUtil;

	// User Registration Logic:
	public UserResponse userRegistration(UserRegistrationRequest request) {

		// Check if username exists
		if (userRepository.existsByUserName(request.getUserName())) {
			throw new UsernameAlreadyExistsException("Username already exists");
		}

		// Check if email exists
		if (userRepository.existsByEmail(request.getEmail())) {
			throw new EmailAlreadyExistsException("Email already exists");
		}

		// Create and save User
		User user = new User();
		user.setUserName(request.getUserName());
		user.setEmail(request.getEmail());
		user.setPassword((request.getPassword()));

		// Set user roles based on isManager flag
		if (request.getIsManager().equalsIgnoreCase("true")) {
			user.setRoles(Set.of(Role.ROLE_MANAGER));
		} else if (request.getIsManager().equalsIgnoreCase("false")) {
			user.setRoles(Set.of(Role.ROLE_CUSTOMER));
		} else {
			throw new RuntimeException("Provide correct value for the field isManager");
		}

		User savedUser = userRepository.save(user);

		// Create CustomerDetails if not a manager
		if (user.getRoles().contains(Role.ROLE_CUSTOMER)) {
			CustomerDetails customerDetails = new CustomerDetails();
			customerDetails.setUser(savedUser);
			customerDetails.setFirstName(request.getFirstName());
			customerDetails.setLastName(request.getLastName());
			customerDetails.setAddress(request.getAddress());
			customerDetailsRepository.save(customerDetails);
		}

		return new UserResponse(savedUser.getId(), savedUser.getEmail(), savedUser.getUserName(), savedUser.getRoles());
	}

	// User Login Logic:
	public LoginResponse userLogin(UserLoginRequest request) {
		User user = userRepository.findByUserName(request.getUsername())
				.orElseThrow(() -> new InvalidUsernameException("Invalid username"));

		// Check if password matches
		if (!request.getPassword().equals(user.getPassword())) {
			throw new InvalidPasswordException("Invalid password");
		}

		String token = jwtUtil.generateToken(user.getUserName(), user.getRoles());

		return new LoginResponse(user.getUserName(), user.getEmail(), token, user.getRoles());
	}

	// validate token
	public void validateToke(String token) {
		jwtUtil.validateToken(token);
	}

	// Fetch Profile Logic:
	public CustomerDetailsResponse getCustomerDetails(Long id) {
		if (id == null || id <= 0) {
			throw new InvalidCustomerIdException("Invalid customer ID: " + id);
		}

		CustomerDetails customerDetails = customerDetailsRepository.findByUserId(id).orElseThrow(
				() -> new CustomerDetailsNotFoundException("Customer details not found for user ID: " + id));

		// Extracting email and country
		String email = customerDetails.getUser().getEmail();
		String country = customerDetails.getAddress().getCountry();

		return new CustomerDetailsResponse(customerDetails.getFirstName(), customerDetails.getLastName(),
				customerDetails.getAddress(), customerDetails.getDob(), email, country);
	}

}
