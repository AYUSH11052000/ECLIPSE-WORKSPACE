package com.edushelf.customerservice.dto;

import java.util.Set;

import com.edushelf.customerservice.Entity.Role;

public class UserResponse {

	private Long id;
	private String userName;
	private String email;
	private Set<Role> roles;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return userName;
	}

	public void setUsername(String username) {
		this.userName = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public UserResponse(Long id, String email, String userName, Set<Role> roles) {
		super();
		this.id = id;
		this.userName = userName;
		this.email = email;
		this.roles = roles;
	}

}
